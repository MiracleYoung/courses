#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/12/17 10:28
# @Author  : Miracle Young
# @File    : api.py

# from django.views import generic
from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.response import Response
from .models import User
from .serializer import UserSerializer
from django.http.response import HttpResponse
import bcrypt

class RegisterApi(APIView):
    # serializer_class = UserSerializer

    def post(self, request, *args, **kwargs):
        # super().create(request, *args, **kwargs)
        name = request.data.get('name')
        mail = request.data.get('mail')
        password = request.data.get('password')
        hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
        user = User(name=name, mail=mail, password=hashed_password)
        user.save()
        return Response({'user_id': user.id})

class LoginApi(APIView):
    def post(self, request, **kwargs):
        mail = request.data.get('mail', '')
        password = request.data.get('password', '')
        user = User.objects.filter(mail=mail).first()
        if bcrypt.checkpw(password.encode(), user.password.encode()):
            return Response({'user_id': user.id, 'user_mail': user.mail})