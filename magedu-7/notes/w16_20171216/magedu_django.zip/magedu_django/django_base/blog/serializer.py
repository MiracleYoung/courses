#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/12/17 11:03
# @Author  : Miracle Young
# @File    : serializer.py

from rest_framework import serializers
from .models import User

class UserSerializer(serializers.ModelSerializer):

    class Meta:
        model = User