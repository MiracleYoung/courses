#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/12/17 10:37
# @Author  : Miracle Young
# @File    : urls.py

from django.conf.urls import url
from .api import RegisterApi, LoginApi

app_name = 'api-blog'

urlpatterns = [
    url(r'^register/$', RegisterApi.as_view(), name='register'),
    url(r'^login/$', LoginApi.as_view(), name='login'),
]