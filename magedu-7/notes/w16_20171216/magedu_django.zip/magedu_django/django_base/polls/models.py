from django.db import models
from django.utils import timezone
import datetime
# Create your models here.

class Question(models.Model):
    # id = models.AutoField(primary_key=True)
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date published')

    def was_published_recently(self):
        return self.pub_date >= timezone.now() - datetime.timedelta(days=1)

    def __str__(self):
        return self.question_text

    @classmethod
    def create(self):
        self.question_text = 'queston test'
        self.pub_date = timezone.now()
        self.save()


    __repr__ = __str__

    class Meta:
        db_table = 'question'

class Choice(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)

    def __str__(self):
        return self.choice_text

    __repr__ = __str__

    class Meta:
        db_table = 'choice'


# question = Question()
# question.pub_date = timezone.now()
# question.question_text = ''
# question.save()
#
#
# question = Question(pub_date=timezone.now(), question_text='')
# question.save()
#
# question = Question().create()
# question = Question.create()

# strftime strptime  => year
# question.pub_date
