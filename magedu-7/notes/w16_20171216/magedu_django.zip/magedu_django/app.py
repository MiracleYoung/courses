#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/12/16 9:16
# @Author  : Miracle
# @File    : app.py
# @Software: PyCharm

def fn():
    pass


