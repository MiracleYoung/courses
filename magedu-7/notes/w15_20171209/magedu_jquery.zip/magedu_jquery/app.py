import flask
from flask import jsonify
from flask import Response
from flask import render_template

app = flask.Flask(__name__)

@app.route('/test')
def test():
    return "Hello, World!"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api')
def api():
    return jsonify({'email': '123'})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)