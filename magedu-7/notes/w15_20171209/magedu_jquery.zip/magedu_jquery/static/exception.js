// throw new Error('some error')

// throw 'some error'

// throw {a: 1}

// thorw () => {}

// 捕获异常

// try {
//     throw new Error('some error')
// } catch (error) {
//     console.log(error)
// }

// try {
//     throw {message: 'some error', code: 500}
// } catch (error) { // 所以catch 中 捕获的对象error 就是throw 的对象
//     console.log(error)
// }

// try {
//     throw {message: 'some error', code: 500}
// } catch (error) { // 所以catch 中 捕获的对象error 就是throw 的对象
//     console.log(`${error.message}, ${error.code}`)
// }

// try {
//     throw {message: 'some error', code: 500}
// } catch (error) { // 所以catch 中 捕获的对象error 就是throw 的对象
//     console.log(`${error.message}, ${error.code}`)
// } catch (error) {
//     console.log(`${error.message}, ${error.code}`)
// }

try {
    throw {message: 'some error', code: 500}
} catch (error) { // 所以catch 中 捕获的对象error 就是throw 的对象
    console.log(`${error.message}, ${error.code}`)
} finally {
    console.log('finally')
}
/*
- 只有1个 catch, 有且仅有一个，并且没有优先级
- finally，可选参数，总是会被执行到

*/