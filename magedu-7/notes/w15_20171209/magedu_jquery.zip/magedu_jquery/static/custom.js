$.ajax({
    url: 'http://127.0.0.1:5000/'
}).done(function(data){
    console.log(data)
})