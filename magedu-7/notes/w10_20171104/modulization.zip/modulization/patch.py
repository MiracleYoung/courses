#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/11/4 16:16
# @Author  : Miracle
# @File    : patch.py
# @Software: PyCharm

import custom_module

def install():
    custom_module.fn = lambda : print('patched')