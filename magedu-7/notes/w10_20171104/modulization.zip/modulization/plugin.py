#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/11/4 17:46
# @Author  : Miracle
# @File    : plugin.py
# @Software: PyCharm

import importlib

class BasePlugin:
    def run(self):
        raise NotImplemented


def load(name):
    # name = module:class
    mod, _, cls_name = name.partition(':')
    cls = getattr(importlib.import_module(mod), cls_name)
    return cls()