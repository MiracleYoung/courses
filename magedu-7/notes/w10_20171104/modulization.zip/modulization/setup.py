#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/11/4 17:32
# @Author  : Miracle
# @File    : setup.py
# @Software: PyCharm


from distutils.core import setup

setup(name='m', version='0.0.1', packages=['m', 'm.sub'])

# packages 参数 需要引入的是  二级目录及以下目录，并不引入  一级目录

