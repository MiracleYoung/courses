#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/11/4 16:12
# @Author  : Miracle
# @File    : mm.py
# @Software: PyCharm


import custom_module

print(custom_module.foo)