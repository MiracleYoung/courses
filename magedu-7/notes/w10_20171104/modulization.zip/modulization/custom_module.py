#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/11/4 14:22
# @Author  : Miracle
# @File    : custom_module.py
# @Software: PyCharm

# print('this is a custom module')

# import subprocess
#
# subprocess.Popen(['shutdown', '-h', 'now'])
#
# import shutil
#
# shutil.rmtree('/')


# print(__file__) # 查阅一些资源的时候，能够正确找到我们的资源
# print(__name__) # 比较有用
# print(__spec__) # 模块的信息
#
# def main():
#     pass
#
# if __name__ == '__main__':
#     print('this is main module')

foo = 'abc'
__foo = '__foo'


def main():
    print('main')

def __main():
    print('__main')

def fn():
    print('this is custom module fn()')

def _bar():
    print('_bar')

__all__ = ['__main', 'foo']

# if __name__ == '__main__':
#     main()
#     print('this is main module')