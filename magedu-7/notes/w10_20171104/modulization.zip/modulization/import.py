#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/11/4 14:11
# @Author  : Miracle
# @File    : import.py
# @Software: PyCharm


# import os, sys # 完全导入

# 部分引用，部分导入
# from module import submodule
# from os import path

# import os as system
# from os import path as os_path
# import os
# print(os.getcwd())
#
# from os import path
#
# print(path.basename(os.getcwd()))

# import os as system
# from os import path as os_path
#
# print(os_path.basename(system.getcwd()))

# import os as system

# import os
# system = os
# del os 因为模块进行别名的时候，会销毁原有的命名空间

# system.getcwd()

# import os.path
#
# print(os.path.basename(os.getcwd()))

# from . import custom_module

# from . import custom-module # 短横杠 是不符合我们python 的命名规范的

# python 中，python 文件即是模块，模块名为文件名
# 有因为，文件名是模块名，所以要求文件名必须符合python 标识符规范，否则无法导入
#
# import os
#
# print(os.path)

# import sys
#
# for s in sys.path: # sys.path 指定了模块的查找路径
#     print(s)


# 自定义模块是一个python 文件
# 自定义模块的文件名必须符合python 标识符规范
# 应该避免命名冲突

# 字母，数字，下划线，但是不能以数字开头
# 通常情况下，我们的模块名都定义成小写的
# 若有多个单词使用下划线分割，因为有些系统比如windows 不区分大小写，就有问题了。

# import custom_module # 引入模块其实就是 执行该模块
# import custom_module
# import custom_module
# import custom_module # 导入多次只会执行一次
#
# print(locals())

# import custom_module

# 目录作为模块以及子模块

# import m # 模块的内容写在__init__.py中

# print(m.__name__)
# print(m.__file__)
# print(type(m))

# import m.foo # foo 是m 的子模块

# from m import foo
# import m.foo
# import m.foo
#
# m.

# 导入父模块，不会自动导入子模块，导入子模块，会自动导入父模块

# 15分钟 练习
#
# 15分钟休息


# from json import encoder
#

# import m.foo
#
# m.foo.foo()
# m.fn()

# import m
#
# import json
#
# from json import decoder

# import __private_module # 并不存在 私有模块

# import custom_module

# print(custom_module.foo) # 模块的变量是可以被引用的
#
# print(custom_module.__foo) # 模块中不存在私有变量

# custom_module.__main()

# _private_module__ 模块中的 私有成员


# import contextlib
#
# contextlib.contextmanager()

# print(custom_module.foo)
# custom_module.foo = 5
# print(custom_module.foo) # 模块的变量是可以被修改的

# import custom_module
#
# print(custom_module.foo)
#
# import mm
#
# custom_module.foo = 5
#
# print(mm.custom_module.foo)
# print(custom_module.foo) # 模块变量的修改是全局的，并且在再次引入该模块的时候，变量是修改后的

# import custom_module
# import patch

# patch.py
# import custom_module
#
# def install():
#     custom_module.fn = lambda : print('patched')

# custom_module.py
# def fn():
#     print('this is custom module fn()')

# patch.install()
# custom_module.fn() # 猴子补丁




# import custom_module
#
# old = custom_module.fn # backup
#
# import patch
#
# patch.install()
# custom_module.fn()
#
# custom_module.fn = old
# custom_module.fn()

# from custom_module import fn
#
# from custom_module import foo # 部分引入，还可以引入成员变量

# from custom_module import *

# fn()
# print(foo)
# __main() # 双下划线开始的 都不能引入
# _bar() # 下划线开始的  都不能印入，

# 当使用一个模块定义了__all__属性时，使用部分引用，只会导入__all__指定的成员
# 如果没有定义__all__属性，那么 会导入非下划线开始的成员

# from m import *
# fn() # 通过 指定__all__ 属性，可以将子模块的成员 也一并导入


# 当然了，__all__ 方法只有和import * 配合使用的时候，才会有意义
# __all__ 写在模块m 的 __init__.py 这个文件里
# from m import fn
# fn()

# import m

from m.foo import fn # 绝对导入
from .m.foo import fn # 相对导入

import m.bar