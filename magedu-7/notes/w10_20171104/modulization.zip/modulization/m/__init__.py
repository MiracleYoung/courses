#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/11/4 15:16
# @Author  : Miracle
# @File    : __init__.py
# @Software: PyCharm


# print('this is dir module')

def fn():
    print('m/__init__.py fn()')
print('m')

def bar():
    print('bar')

import m.foo # 这里就涉及到 sys.path 并不会被递归查找的 问题

from m import foo # 绝对导入
from . import foo # 相对导入

__all__ = ['foo']