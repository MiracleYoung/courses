#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/11/4 15:22
# @Author  : Miracle
# @File    : foo.py
# @Software: PyCharm

def foo():
    pass


def fn():
    print('foo')

print('m.foo')