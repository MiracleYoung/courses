#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/11/4 17:18
# @Author  : Miracle
# @File    : __init__.py.py
# @Software: PyCharm

from ...foo import fn # 使用相对导入的模块，并不能够被直接执行


fn()